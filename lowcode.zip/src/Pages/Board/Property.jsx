import React, { useState } from 'react'
import { BiText } from 'react-icons/bi';

function Property({ extraClass = "w-full text-[#4D4D4D] hover:text-[#FFFFFF] hover:bg-[#227A60] text-center text-sm border border-[#E9E9E9] rounded-lg py-2" }) {
  const [draggedItem, setDraggedItem] = useState(null);
  const AdvancecFields = [
    {
      title: 'Kanban',
      inputType: 'text',
      icon: <BiText />,
    },
  ]
  const [options, setoption] = useState([
    "status",
    "gender"
  ]);


  return (
    <>
   
      <div className="w-full h-full flex flex-row px-7 py-5 pb-6 gap-5">
       

       {/* <DndProvider backend={HTML5Backend}> */}

        <div className="w-1/3 h-full bg-[#fff] rounded-2xl flex flex-col p-4"
        >
          {
            AdvancecFields.map((field, index) => (
              <button

                key={index}
                type="button"
                className={`rounded-md px-4 py-2 flex space-x-2 shadow-[0_0_14px_0_rgba(34,122,96,0.1)] ${extraClass} h-[40px] items-center`}

              >
                {field.icon}
                <span>{field.title}</span>

              </button>
            ))}

        </div>



        <div className="w-1/2 h-full bg-[#fff] rounded-2xl flex flex-col">

        </div>
       {/* </DndProvider> */}




        <div className="w-1/3 h-full bg-[#fff] rounded-2xl flex flex-col">

          <div className="flex flex-col space-y-1 p-2">
            <label className="block mb-2 mt-2 text-lg font-medium text-gray-900 font-bold">
              Kanban Name
            </label>
            <input type='text' placeholder='kanban name'
              className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:border-indigo-500"
            />
          </div>
          <div className="flex flex-col space-y-1 p-2">
            <label className="block mb-2 mt-2 text-lg font-medium text-gray-900 font-bold">
              Column Name
            </label>
            <select id="countries" className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">

              {
                options.map((option, index) => {
                  return <option key={index} value={option}>{option}
                  </option>
                }
                )}

            </select>
          </div>
        </div>

      </div>
    </>
  )
}
export default Property;
