import React from 'react';

const ModuleBuilder = () => {
  return <div>ModuleBuilder</div>;
};

export default ModuleBuilder;
